#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <strings.h>

typedef struct User {
    char* first; /* the user's given name */
    char* last;  /* the user's surname */
    int   followers; /* the number of followers this user has */
} User;

/* Local function declarations -- DO NOT CHANGE */
int* range(int start, int stop, int step);
char* User_toString(User user);
void growArray(int** A, size_t currentSize, size_t newSize);
void testRange();
void testUserString();
void testGrowArray();
void printArray(int* A, size_t LEN);

int main(int argc, char* argv[]) {
    printf("\n=============================================================\n");
    printf("TESTING RANGE\n");
    printf("=============================================================\n");
    testRange();
    printf("\n=============================================================\n");
    printf("TESTING USER STRING\n");
    printf("=============================================================\n");
    testUserString();
    printf("\n=============================================================\n");
    printf("TESTING GROW ARRAY\n");
    printf("=============================================================\n");
    testGrowArray();
    return EXIT_SUCCESS;
}

/*******************************************************************************
 * Test Functions
*******************************************************************************/
void testRange() {
    // Instantiate two arrays, fill them with incrementing i, then free the arrays
    int* A = malloc(5* sizeof(int));
    for (int i = 0; i < 5; i++) { 
        A[i] = i+1; }
    range(0,5,1);
    free(A);

    int* B = malloc(20* sizeof(int));
    for (int i = 0; i < 20; i++) { 
        B[i] = i+1; }
    range(0,20,1);
    free(B);
}

void testUserString() {
    //Create User struct, then fill it's variables and call the toString method
    User Strawhat;
    Strawhat.first = "Monkey D.";
    Strawhat.last = "Luffy";
    Strawhat.followers = 523200000;
    User_toString(Strawhat);
}

/* 
    NOTE: This test is provided to help you understand how your growArray
    function should work. You may want to add more thorough testing, but it is 
    not required that you do so. Obviously this function will not SEGFAULT once 
    growArray works correctly. It should also report two different memory 
    addresses for A from before and after calling growArray.
*/
void testGrowArray() {
    // initialize some array A
    int* A = calloc(5, sizeof(int));
    for (int i = 0; i < 5; i++) { A[i] = i+1; }
    // print out the memory address of the array and its contents
    printf("A is located at: %p\n", A);
    printArray(A, 5);
    // grow the array and add some more items
    growArray(&A, 5, 100);
    for (int i = 5; i < 100; i++) {A[i] = i+1; }
    // print out the memory address of the array and its contents
    printf("A is located at: %p\n", A);
    printArray(A, 100);
    free(A); // free remaining array
}

/*******************************************************************************
 * Function Implementations
*******************************************************************************/

/**
 * @brief Range - Return Array
 * 
 * @param start the index in an array the method starts at
 * @param stop the index in an array the method ends at
 * @param step the amount in which the method iterates through the array
 * 
 * @return An array identical to one that the Python Range function would produce with the same inputs
 */
int* range(int start, int stop, int step) {
    int* Arr = malloc((stop-start)* sizeof(int));
    for(int i = start; i<=stop; i+=step){
        printf("%d\n", i);
    }
    return Arr;
    free(Arr);
}

/**
 * @brief User_toString - takes the three variables of a user struct, and 
 * 
 * @param user a struct used to represent a user with a first name, last name, and follower count
 * 
 * @returns The contents of a user (first, last, and followers) as a string
 */
char* User_toString(User user) {    
    double followerlen = log10(user.followers);
    int len = printf(strlen(user.first)+strlen(user.last)+sizeof(followerlen));
    char* nuser = malloc(len);
    char* Strng = snprintf(nuser, len, "%s %s (%d)", user.first, user.last, user.followers);
    return Strng;
    free(Strng);
}

/**
 * @brief growArray
 * 
 * @param Aptr A pointer for the int* A to traverse itself
 * @param currentSize the current length of A
 * @param newSize the new length of A
 * 
 * @returns nothing
 */
void growArray(int** Aptr, size_t currentSize, size_t newSize) {
    int** new = calloc(newSize, sizeof(int));
        for(int i = 0; i<newSize; i++){
            new[i] = Aptr[i];
        }
    free(Aptr);
    Aptr = new;
    free(new);
}

/*******************************************************************************
 * Helper Functions
*******************************************************************************/

/**
 * @brief Simple utility function to print the contents of an int array
 * 
 * @param A   the array to be printed
 * @param LEN the length of A
 */
void printArray(int* A, size_t LEN) {
    printf("[ ");
    for (int i = 0; i < LEN; i++) {
        printf("%d ", A[i]);
    }
    printf("]\n");
}