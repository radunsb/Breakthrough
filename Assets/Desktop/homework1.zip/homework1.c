/**
 * @file homework1.c
 * @author Brayden Stuchell
 * @brief A demonstration of three methods, to prove knowledge of C basics
 * @date 2024-02-13
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>

typedef struct SizedArray {
    int* vals;
    size_t length;
} SizedArray;

bool isLeap(int year){
    if(year%4 == 0){
        if(year%100 !=0){
            if(year%400 == 0){
            printf("%d is not a leap year\n", year);
            return false;
        }else{
            printf("%d is a leap year\n", year);
            return true;
        }
        }else{
            if(year % 400 == 0){
            printf("%d is a leap year\n", year);
            return true;
        }else{
            printf("%d is not a leap year\n", year);
            return false;
            }
        }
    }else{
        printf("%d is not a leap year\n", year);
        return false;
    }

}
/**
 * @brief Return a true or false variable whether or not a given year is indeed a leap year
 * 
 * @param year The given year to be tested for leap-ness
 * @return bool of the given years leap status
 */

double estimatePi(int n){
    double estimate = 1.0;
    for(int i = 3; i<n; i+=2){
            estimate = estimate - (1/i) + (1/(i+2));
    }
    if(n==1){
        printf("With %d fraction, we estimate pi to be %f when it is actually %f\n", n, estimate*4, M_PI);
    }else{
    printf("With %d fractions, we estimate pi to be %f when it is actually %f\n", n, estimate*4, M_PI);
    }
}

/**
 * @brief Return an estimation of pi/4 based on the number of leibniz fractions used to calculate it
 * 
 * @param n The number of leibniz fractions to be used in the estimation of pi/4
 * @return the integer calculated compared to the mathimatically accurate pi found in <math.h>
 */

void selectionSort(size_t len, int* A){
    for(int i = 0; i<len; i++){
        int max = A[i];
        int maxIndex = i;
        for(int j = i; j<len; j++){
            if (A[j]>max){
            max = A[j];
            maxIndex = j;
        }
        int temp = A[i];
            A[i] = A[j];
            A[j] = temp;
        }
    }
}

/**
 * @brief Sort a given array by selection sort in descending order
 * 
 * @param len the length of the array
 * @param A the array to be sorted
 * @return the array A, now sorted from Largest to smallest number
 */

int main(int argc, char* argv[]) {
    isLeap(2024);
    isLeap(2000);
    isLeap(1700);
    isLeap(1969);

    estimatePi(1);
    estimatePi(20);
    estimatePi(101);

    SizedArray A;
    int a[] = {1,2,3,4,5};
    A.vals = a;
    A.length = 5;
    SizedArray B;
    int b[] = {9,1,5,9,2};
    B.vals = b;
    B.length = 5;
    SizedArray C;
    int c[] = {1,8,8};
    C.vals = c;
    C.length = 3;

    selectionSort(5, A.vals);
        for(int i = 0; i<A.length; i++){
        printf("%d", A.vals[i]);
    }
    printf("\n");
    selectionSort(5, B.vals);
        for(int i = 0; i<B.length; i++){
        printf("%d", B.vals[i]);
    }
    printf("\n");
    selectionSort(3, C.vals);
        for(int i = 0; i<C.length; i++){
        printf("%d", C.vals[i]);
    }
    printf("\n");
    return EXIT_SUCCESS;

}